# Modified 2026-10-10: Dailymotion TLS compatibility and playback error handling.
'''
    Dailymotion_com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import six
from kodi_six import xbmcplugin, xbmcaddon, xbmcgui, xbmc, xbmcvfs
import sys
import re
import json
import datetime
from resources.lib import client
from six.moves import urllib_parse, urllib_error
# HTMLParser() deprecated in Python 3.4 and removed in Python 3.9
if sys.version_info >= (3, 4, 0):
    import html
    _html_parser = html
else:
    from six.moves import html_parser
    _html_parser = html_parser.HTMLParser()

pluginhandle = int(sys.argv[1])
addon = xbmcaddon.Addon()
addonID = addon.getAddonInfo('id')
_icon = addon.getAddonInfo('icon')
_fanart = addon.getAddonInfo('fanart')
_path = addon.getAddonInfo('path')
_ipath = '{0}/resources/images/'.format(_path)
_kodiver = float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4])

if hasattr(xbmcvfs, "translatePath"):
    translate_path = xbmcvfs.translatePath
else:
    translate_path = xbmc.translatePath
channelFavsFile = translate_path("special://profile/addon_data/{0}/{0}.favorites".format(addonID))
HistoryFile = translate_path("special://profile/addon_data/{0}/{0}.history".format(addonID))
cookie_file = translate_path("special://profile/addon_data/{0}/cookies".format(addonID))
pDialog = xbmcgui.DialogProgress()
familyFilter = '1'

if not xbmcvfs.exists('special://profile/addon_data/' + addonID + '/settings.xml'):
    addon.openSettings()

if addon.getSetting('family_filter') == 'false':
    familyFilter = '0'

force_mode = addon.getSetting("forceViewMode") == "true"
if force_mode:
    menu_mode = addon.getSetting("MenuMode")
    video_mode = addon.getSetting("VideoMode")

maxVideoQuality = addon.getSetting("maxVideoQuality")
qual = ['240', '380', '480', '720', '1080', '1440', '2160']
maxVideoQuality = qual[int(maxVideoQuality)]
language = addon.getSetting("language")
languages = ["ar_ES", "br_PT", "ca_EN", "ca_FR", "de_DE", "es_ES", "fr_FR",
             "in_EN", "id_ID", "it_IT", "ci_FR", "my_MS", "mx_ES", "pk_EN",
             "ph_EN", "tr_TR", "en_GB", "en_US", "vn_VI", "kr_KO", "tw_TW"]
language = languages[int(language)]
dmUser = addon.getSetting("dmUser")
itemsPerPage = addon.getSetting("itemsPerPage")
itemsPage = ["25", "50", "75", "100"]
itemsPerPage = itemsPage[int(itemsPerPage)]
urlMain = "https://api.dailymotion.com"
_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0'


def strip_tags(text):
    clean = re.compile('<.*?>')
    return re.sub(clean, '', text)


def index():
    addDir(translation(30025), "{0}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&list=what-to-watch&no_live=1&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language), 'listVideos', "{0}what_to_watch.png".format(_ipath))
    addDir(translation(30015), "{0}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&sort=trending&no_live=1&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language), 'listVideos', "{0}trending.png".format(_ipath))
    addDir(translation(30016), "{0}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&featured=1&no_live=1&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language), 'listVideos', "{0}featured.png".format(_ipath))
    addDir(translation(30003), "{0}/videos?fields=id,thumbnail_large_url,title,views_last_hour&availability=1&live_onair=1&sort=visited-month&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language), 'listLive', "{0}live.png".format(_ipath))
    addDir(translation(30006), "", 'listChannels', "{0}channels.png".format(_ipath))
    addDir(translation(30007), "{0}/users?fields=username,avatar_large_url,videos_total,views_total&sort=popular&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language), 'listUsers', "{0}users.png".format(_ipath))
    # Run the search dialog as an action, outside Kodi's folder-loading guard.
    addDir(translation(30002), "{0}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&search=&sort=relevance&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language), 'search', "{0}search.png".format(_ipath), is_folder=False)
    addDir("{0} {1}".format(translation(30002), translation(30003)), "", 'livesearch', "{0}search_live.png".format(_ipath))
    addDir("{0} {1}".format(translation(30002), translation(30007)), "", 'usersearch', "{0}search_users.png".format(_ipath))
    addDir(translation(30115), "", "History", "{0}search.png".format(_ipath))
    if dmUser:
        addDir(translation(30034), "", "personalMain", "{0}my_stuff.png".format(_ipath))
    else:
        addFavDir(translation(30024), "", "favouriteUsers", "{0}favourite_users.png".format(_ipath))
    xbmcplugin.setContent(pluginhandle, "files")
    xbmcplugin.endOfDirectory(pluginhandle)
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def update_listitem(li, infoLabels):
    if isinstance(infoLabels, dict):
        labels = infoLabels.copy()
        if _kodiver > 19.8:
            vtag = li.getVideoInfoTag()
            if labels.get('Title'):
                vtag.setTitle(labels['Title'])
            if labels.get('Plot'):
                vtag.setPlot(labels['Plot'])
            if labels.get('Duration'):
                vtag.setDuration(labels['Duration'])
            if labels.get('Aired'):
                vtag.setFirstAired(labels['Aired'])
            if labels.get('Episode'):
                vtag.setEpisode(int(labels['Episode']))
        else:
            li.setInfo(type='Video', infoLabels=labels)

    return


def make_listitem(name='', labels=None, path=''):
    if _kodiver >= 18.0:  # Include Kodi version 18 in the condition
        offscreen = True
        if name:
            li = xbmcgui.ListItem(name, offscreen=offscreen)
        else:
            li = xbmcgui.ListItem(path=path, offscreen=offscreen)
    else:
        if name:
            li = xbmcgui.ListItem(name)
        else:
            li = xbmcgui.ListItem(path=path)

    if isinstance(labels, dict):
        update_listitem(li, labels)
    return li


def personalMain():
    addDir(translation(30041), "{0}/user/{1}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, dmUser, itemsPerPage, familyFilter, language), 'listVideos', "{0}videos.png".format(_ipath))
    addDir(translation(30035), "{0}/user/{1}/following?fields=username,avatar_large_url,videos_total,views_total&sort=popular&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, dmUser, itemsPerPage, familyFilter, language), 'listUsers', "{0}contacts.png".format(_ipath))
    addDir(translation(30036), "{0}/user/{1}/subscriptions?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, dmUser, itemsPerPage, familyFilter, language), 'listVideos', "{0}following.png".format(_ipath))
    addDir(translation(30037), "{0}/user/{1}/favorites?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, dmUser, itemsPerPage, familyFilter, language), 'listVideos', "{0}favourites.png".format(_ipath))
    addDir(translation(30038), "{0}/user/{1}/playlists?fields=id,name,videos_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, dmUser, itemsPerPage, familyFilter, language), 'listUserPlaylists', "{0}playlists.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, 'addons')
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def listUserPlaylists(url):
    content = getUrl2(url)
    for item in content['list']:
        vid = item['id']
        title = item['name'].encode('utf-8') if six.PY2 else item['name']
        vids = item['videos_total']
        addDir("{0} ({1})".format(title, vids), urllib_parse.quote_plus("{0}_{1}_{2}".format(vid, dmUser, title)), 'showPlaylist', "{0}playlists.png".format(_ipath))
    if content['has_more']:
        currentPage = content['page']
        nextPage = currentPage + 1
        addDir("{0} ({1})".format(translation(30001), nextPage), url.replace("page={0}".format(currentPage), "page={0}".format(nextPage)), 'listUserPlaylists', "{0}next_page2.png".format(_ipath))
    xbmcplugin.setContent(pluginhandle, "episodes")
    xbmcplugin.endOfDirectory(pluginhandle)


def showPlaylist(pid):
    url = "{0}/playlist/{1}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, pid, itemsPerPage, familyFilter, language)
    listVideos(url)


def favouriteUsers():
    xbmcplugin.addSortMethod(pluginhandle, xbmcplugin.SORT_METHOD_LABEL)
    if xbmcvfs.exists(channelFavsFile):
        with open(channelFavsFile, 'r') as fh:
            content = fh.read()
            match = re.compile('###USER###=(.+?)###THUMB###=(.*?)###END###', re.DOTALL).findall(content)
            for user, thumb in match:
                addUserFavDir(user, 'owner:{0}'.format(user), 'sortVideos1', thumb)
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, "addons")
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def listChannels():
    content = getUrl2("{0}/channels?family_filter={1}&localization={2}".format(urlMain, familyFilter, language))
    for item in content['list']:
        cid = item['id']
        title = item['name'].encode('utf-8') if six.PY2 else item['name']
        desc = item['description'].encode('utf-8') if six.PY2 else item['description']
        addDir(title, 'channel:{0}'.format(cid), 'sortVideos1', '{0}channels.png'.format(_ipath), desc)
    xbmcplugin.endOfDirectory(pluginhandle)


def sortVideos1(url):
    item_type = url[:url.find(":")]
    gid = url[url.find(":") + 1:]
    if item_type == "group":
        url = "{0}/group/{1}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, gid, itemsPerPage, familyFilter, language)
    else:
        url = "{0}/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&{1}={2}&sort=recent&limit={3}&family_filter={4}&localization={5}&page=1".format(urlMain, item_type, gid, itemsPerPage, familyFilter, language)
    addDir(translation(30015), url.replace("sort=recent", "sort=trending"), 'listVideos', "{0}trending.png".format(_ipath))
    addDir(translation(30008), url, 'listVideos', "{0}most_recent.png".format(_ipath))
    addDir(translation(30009), url.replace("sort=recent", "sort=visited"), 'sortVideos2', "{0}most_viewed.png".format(_ipath))
    if item_type == "owner":
        addDir("- {0}".format(translation(30038)), "{0}/user/{1}/playlists?fields=id,name,videos_total&sort=recent&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, gid, itemsPerPage, familyFilter, language), 'listUserPlaylists', "{0}playlists.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, 'addons')
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def sortVideos2(url):
    addDir(translation(30010), url.replace("sort=visited", "sort=visited-hour"), "listVideos", "{0}most_viewed.png".format(_ipath))
    addDir(translation(30011), url.replace("sort=visited", "sort=visited-today"), "listVideos", "{0}most_viewed.png".format(_ipath))
    addDir(translation(30012), url.replace("sort=visited", "sort=visited-week"), "listVideos", "{0}most_viewed.png".format(_ipath))
    addDir(translation(30013), url.replace("sort=visited", "sort=visited-month"), "listVideos", "{0}most_viewed.png".format(_ipath))
    addDir(translation(30014), url, 'listVideos', "{0}most_viewed.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, 'addons')
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def sortUsers1():
    url = "{0}/users?fields=username,avatar_large_url,videos_total,views_total&sort=popular&limit={1}&family_filter={2}&localization={3}&page=1".format(urlMain, itemsPerPage, familyFilter, language)
    addDir(translation(30040), url, 'sortUsers2', "")
    addDir(translation(30016), "{0}&filters=featured".format(url), 'sortUsers2', "")
    addDir(translation(30017), "{0}&filters=official".format(url), 'sortUsers2', "")
    addDir(translation(30018), "{0}&filters=creative".format(url), 'sortUsers2', "")
    xbmcplugin.endOfDirectory(pluginhandle)


def sortUsers2(url):
    addDir(translation(30019), url, 'listUsers', "")
    addDir(translation(30020), url.replace("sort=popular", "sort=commented"), 'listUsers', "")
    addDir(translation(30021), url.replace("sort=popular", "sort=rated"), 'listUsers', "")
    xbmcplugin.endOfDirectory(pluginhandle)


def listVideos(url):
    xbmcplugin.setContent(pluginhandle, 'episodes')
    content = getUrl2(url)
    count = 1
    for item in content['list']:
        vid = item['id']
        title = item['title'].encode('utf-8') if six.PY2 else item['title']
        desc = strip_tags(item['description']).encode('utf-8') if six.PY2 else strip_tags(item['description'])
        duration = item['duration']
        user = item['owner.username']
        date = item['taken_time']
        thumb = item['thumbnail_large_url']
        views = item['views_total']
        try:
            date = datetime.datetime.fromtimestamp(int(date)).strftime('%Y-%m-%d')
        except:
            date = ""
        temp = translation(30118).format(user, views, date)
        temp = temp.encode('utf-8') if six.PY2 else temp
        try:
            desc = "{0}\n{1}".format(temp, desc)
        except:
            desc = ""
        if user == "hulu":
            pass
        elif user == "cracklemovies":
            pass
        elif user == "ARTEplus7":
            addLink(title, vid, 'playArte', thumb.replace("\\", ""), user, desc, duration, date, count)
            count += 1
        else:
            addLink(title, vid, 'playVideo', thumb.replace("\\", ""), user, desc, duration, date, count)
            count += 1
    if content['has_more']:
        currentPage = content['page']
        nextPage = currentPage + 1
        addDir("{0} ({1})".format(translation(30001), nextPage), url.replace("page={0}".format(currentPage), "page={0}".format(nextPage)), 'listVideos', "{0}next_page2.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, "episodes")
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(video_mode))


def listUsers(url):
    content = getUrl2(url)
    for item in content['list']:
        if item['username']:
            user = item['username'].encode('utf-8') if six.PY2 else item['username']
            thumb = item['avatar_large_url']
            videos = item['videos_total']
            views = item['views_total']
            addUserDir(user, 'owner:{0}'.format(user), 'sortVideos1', thumb.replace("\\", ""), translation(30119).format(views, videos))
    if content['has_more']:
        currentPage = content['page']
        nextPage = currentPage + 1
        addDir("{0} ({1})".format(translation(30001), nextPage), url.replace("page={0}".format(currentPage), "page={0}".format(nextPage)), 'listUsers', "{0}next_page.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, "addons")
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def listLive(url):
    content = getUrl2(url)
    for item in content['list']:
        title = item['title'].encode('utf-8') if six.PY2 else item['title']
        vid = item['id']
        thumb = item['thumbnail_large_url']
        views = item['views_last_hour']
        addLiveLink(title, vid, 'playLiveVideo', thumb.replace("\\", ""), translation(30120).format(views))
    if content['has_more']:
        currentPage = content['page']
        nextPage = currentPage + 1
        addDir("{0} ({1})".format(translation(30001), nextPage), url.replace("page={0}".format(currentPage), "page={0}".format(nextPage)), 'listLive', "{0}next_page2.png".format(_ipath))
    xbmcplugin.endOfDirectory(pluginhandle)
    xbmcplugin.setContent(pluginhandle, "episodes")
    if force_mode:
        xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def playVideo(vid, live=False):
    if live:
        url = getStreamUrl(vid, live=True)
    else:
        url = getStreamUrl(vid)
    xbmc.log("DAILYMOTION - FinalUrl = {0}".format(url), xbmc.LOGDEBUG)

    if url:
        subs = []
        if isinstance(url, tuple):
            url, subs = url
        listitem = xbmcgui.ListItem(path=url)
        if subs:
            listitem.setSubtitles(subs)
        if '.m3u8' in url:
            listitem.setMimeType("application/x-mpegURL")
        else:
            listitem.setMimeType("video/mp4")
        listitem.setContentLookup(False)
        xbmcplugin.setResolvedUrl(pluginhandle, True, listitem=listitem)
    else:
        xbmcgui.Dialog().notification('Info:', translation(30022), _icon, 5000, False)
        xbmcplugin.setResolvedUrl(pluginhandle, False, xbmcgui.ListItem())


def s(elem):
    if elem[0] == "auto":
        return 1
    else:
        return int(elem[0].split("@")[0])


def _hls_variant(manifest, base_url, limit):
    """Select a variant without assuming NAME or absolute playlist URIs."""
    if not isinstance(manifest, six.string_types) or not manifest.lstrip().startswith('#EXTM3U'):
        return None
    variants = []
    pending = None
    for line in manifest.splitlines():
        line = line.strip()
        if line.startswith('#EXT-X-STREAM-INF:'):
            pending = dict(re.findall(r'([A-Z0-9-]+)=("[^"]*"|[^,]*)', line))
        elif line and not line.startswith('#') and pending is not None:
            name = pending.get('NAME', '').strip('"')
            height = re.match(r'(\d+)', name)
            if not height:
                height = re.search(r'x(\d+)', pending.get('RESOLUTION', ''))
            quality = int(height.group(1)) if height else 0
            bandwidth = pending.get('BANDWIDTH', '0')
            bandwidth = int(bandwidth) if bandwidth.isdigit() else 0
            variants.append((quality, bandwidth, urllib_parse.urljoin(base_url, line).split('#')[0]))
            pending = None
    if variants:
        permitted = [item for item in variants if item[0] <= int(limit)]
        selected = max(permitted) if permitted else min(variants)
        return selected[2]
    if '#EXTINF:' in manifest or '#EXT-X-TARGETDURATION:' in manifest:
        return base_url.split('#')[0]
    return None


def getStreamUrl(vid, live=False):
    cookie = {'lang': language, 'ff': "on" if familyFilter == "1" else "off"}
    # Refresh metadata for each identity: signed URLs may depend on the client.
    agents = [_UA, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36']
    for agent in agents:
        headers = {'User-Agent': agent, 'Origin': 'https://www.dailymotion.com',
                   'Referer': 'https://www.dailymotion.com/'}
        content = client.request("https://www.dailymotion.com/player/metadata/video/{0}".format(vid),
                                 headers=headers, cookie=cookie)
        if not isinstance(content, dict):
            continue
        if content.get('error'):
            error = content['error']
            message = error.get('message') or error.get('title') or translation(30022)
            xbmcgui.Dialog().notification('Dailymotion:', message, _icon, 5000, False)
            return None
        qualities = content.get('qualities') or {}
        if not isinstance(qualities, dict):
            continue
        subtitles = (content.get('subtitles') or {}).get('data') or {}
        subs = [track['urls'][0] for track in subtitles.values()
                if isinstance(track, dict) and track.get('urls')]
        for quality, sources in sorted(qualities.items(), key=s, reverse=True):
            for item in sources:
                media_url = item.get('url')
                media_type = item.get('type') or ''
                if not media_url or not isinstance(media_url, six.string_types):
                    continue
                if live:
                    media_url = media_url.replace('dvr=true&', '')
                stream_headers = dict(headers)
                if 'mpegurl' in media_type.lower() or '.m3u8' in media_url:
                    result = client.request(media_url, headers=stream_headers, return_url=True)
                    if not result:
                        continue
                    manifest, final_url = result
                    stream = _hls_variant(manifest, final_url, maxVideoQuality)
                elif media_type.startswith('video/') and quality != 'auto' and int(quality.split('@')[0]) <= int(maxVideoQuality):
                    stream = media_url
                else:
                    continue
                if stream:
                    xbmc.log('DAILYMOTION - Resolved video {0}'.format(vid), xbmc.LOGDEBUG)
                    stream = '{0}|{1}'.format(stream, urllib_parse.urlencode(stream_headers))
                    return (stream, subs) if subs else stream
    xbmc.log('DAILYMOTION - No playable playlist for video {0}; see HTTP errors above'.format(vid), xbmc.LOGERROR)
    return None


def queueVideo(url, name):
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    listitem = xbmcgui.ListItem(name)
    playlist.add(url, listitem)


def playArte(aid):
    try:
        content = getUrl2("http://www.dailymotion.com/video/{0}".format(aid))
        match = re.compile(r'<a\s*class="link"\s*href="http://videos.arte.tv/(.+?)/videos/(.+?).html">', re.DOTALL).findall(content)
        lang = match[0][0]
        vid = match[0][1]
        url = "http://videos.arte.tv/{0}/do_delegate/videos/{1},view,asPlayerXml.xml".format(lang, vid)
        content = getUrl2(url)
        match = re.compile(r'<video\s*lang="{0}"\s*ref="(.+?)"'.format(lang), re.DOTALL).findall(content)
        url = match[0]
        content = getUrl2(url)
        match1 = re.compile(r'<url\s*quality="hd">(.+?)</url>', re.DOTALL).findall(content)
        match2 = re.compile(r'<url\s*quality="sd">(.+?)</url>', re.DOTALL).findall(content)
        urlNew = ""
        if match1:
            urlNew = match1[0]
        elif match2:
            urlNew = match2[0]
        urlNew = urlNew.replace("MP4:", "mp4:")
        base = urlNew[:urlNew.find("mp4:")]
        playpath = urlNew[urlNew.find("mp4:"):]
        listitem = xbmcgui.ListItem(path="{0} playpath={1} swfVfy=1 swfUrl=http://videos.arte.tv/blob/web/i18n/view/player_24-3188338-data-5168030.swf".format(base, playpath))
        xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
    except:
        xbmcgui.Dialog().notification('Info:', translation(30110) + ' (Arte)!', _icon, 5000, False)


def addFav():
    keyboard = xbmc.Keyboard('', translation(30033))
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        user = keyboard.getText()
        channelEntry = "###USER###={0}###THUMB###=###END###".format(user)
        if xbmcvfs.exists(channelFavsFile):
            with open(channelFavsFile, 'r') as fh:
                content = fh.read()
            if content.find(channelEntry) == -1:
                with open(channelFavsFile, 'a') as fh:
                    fh.write(channelEntry + "\n")
        else:
            with open(channelFavsFile, 'a') as fh:
                fh.write(channelEntry + "\n")
        xbmcgui.Dialog().notification('Info:', translation(30030), _icon, 5000, False)


def favourites(param):
    mode = param[param.find("###MODE###=") + 11:]
    mode = mode[:mode.find("###")]
    channelEntry = param[param.find("###USER###="):]
    user = param[11 + param.find("###USER###="):param.find("###THUMB###")]
    user = user.encode('utf8') if six.PY2 else user
    if mode == "ADD":
        if xbmcvfs.exists(channelFavsFile):
            with open(channelFavsFile, 'r') as fh:
                content = fh.read()
            if content.find(channelEntry) == -1:
                with open(channelFavsFile, 'a') as fh:
                    fh.write(channelEntry + "\n")
        else:
            with open(channelFavsFile, 'a') as fh:
                fh.write(channelEntry + "\n")
            fh.close()
        xbmcgui.Dialog().notification('Info:', '{0} {1}!'.format(user, translation(30030)), _icon, 5000, False)
    elif mode == "REMOVE":
        refresh = param[param.find("###REFRESH###=") + 14:]
        refresh = refresh[:refresh.find("###USER###=")]
        with open(channelFavsFile, 'r') as fh:
            content = fh.read()
        # entry = content[content.find(channelEntry):]
        with open(channelFavsFile, 'w') as fh:
            fh.write(content.replace(channelEntry + "\n", ""))
        if refresh == "TRUE":
            xbmc.executebuiltin("Container.Refresh")


def translation(lid):
    return addon.getLocalizedString(lid).encode('utf-8') if six.PY2 else addon.getLocalizedString(lid)


def getUrl2(url):
    xbmc.log('DAILYMOTION - The url is {0}'.format(url), xbmc.LOGDEBUG)
    headers = {'User-Agent': _UA}
    cookie = {'lang': language,
              'ff': "on" if familyFilter == "1" else "off"}
    r = client.request(url, headers=headers, cookie=cookie)
    return r


def parameters_string_to_dict(parameters):
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict


def addLink(name, url, mode, iconimage, user, desc, duration, date, nr):
    u = "{0}?url={1}&mode={2}".format(sys.argv[0], urllib_parse.quote_plus(url), mode)
    ok = True
    liz = make_listitem(name=name, labels={"Title": name, "Plot": desc, "Aired": date, "Duration": duration, "Episode": nr})
    liz.setArt({'thumb': iconimage,
                'icon': _icon,
                'poster': iconimage,
                'fanart': _fanart})
    liz.setProperty('IsPlayable', 'true')
    entries = []
    entries.append((translation(30043), 'RunPlugin(plugin://{0}/?mode=queueVideo&url={1}&name={2})'.format(addonID, urllib_parse.quote_plus(u), urllib_parse.quote_plus(name)),))
    if dmUser == "":
        playListInfos = "###MODE###=ADD###USER###={0}###THUMB###=DefaultVideo.png###END###".format(user)
        entries.append((translation(30028), 'RunPlugin(plugin://{0}/?mode=favourites&url={1})'.format(addonID, urllib_parse.quote_plus(playListInfos)),))
    liz.addContextMenuItems(entries)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
    return ok


def addLiveLink(name, url, mode, iconimage, desc):
    u = "{0}?url={1}&mode={2}".format(sys.argv[0], urllib_parse.quote_plus(url), mode)
    ok = True
    liz = make_listitem(name=name, labels={"Title": name, "Plot": desc})
    liz = xbmcgui.ListItem(name)
    liz.setArt({'thumb': iconimage,
                'icon': _icon,
                'poster': iconimage,
                'fanart': _fanart})
    liz.setProperty('IsPlayable', 'true')
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
    return ok


def addDir(name, url, mode, iconimage, desc="", is_folder=True):
    u = "{0}?url={1}&mode={2}".format(sys.argv[0], urllib_parse.quote_plus(url), mode)
    ok = True
    liz = make_listitem(name=name, labels={"Title": name, "Plot": desc})
    liz.setArt({'thumb': iconimage,
                'icon': _icon,
                'poster': iconimage,
                'fanart': _fanart})
    if not is_folder:
        liz.setProperty('IsPlayable', 'false')
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=is_folder)
    return ok


def addUserDir(name, url, mode, iconimage, desc):
    u = "{0}?url={1}&mode={2}".format(sys.argv[0], urllib_parse.quote_plus(url), mode)
    ok = True
    liz = make_listitem(name=name, labels={"Title": name, "Plot": desc})
    liz.setArt({'thumb': iconimage,
                'icon': _icon,
                'poster': iconimage,
                'fanart': _fanart})
    if dmUser == "":
        playListInfos = "###MODE###=ADD###USER###={0}###THUMB###={1}###END###".format(name, iconimage)
        liz.addContextMenuItems([(translation(30028), 'RunPlugin(plugin://{0}/?mode=favourites&url={1})'.format(addonID, urllib_parse.quote_plus(playListInfos)),)])
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok


def addFavDir(name, url, mode, iconimage):
    u = "{0}?url={1}&mode={2}".format(sys.argv[0], urllib_parse.quote_plus(url), mode)
    ok = True
    liz = make_listitem(name=name, labels={"Title": name})
    liz.setArt({'thumb': iconimage,
                'icon': _icon,
                'poster': iconimage,
                'fanart': _fanart})
    liz.addContextMenuItems([(translation(30033), 'RunPlugin(plugin://{0}/?mode=addFav)'.format('addonID'),)])
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok


def addUserFavDir(name, url, mode, iconimage):
    u = "{0}?url={1}&mode={2}".format(sys.argv[0], urllib_parse.quote_plus(url), mode)
    ok = True
    liz = make_listitem(name=name, labels={"Title": name})
    liz.setArt({'thumb': iconimage,
                'icon': _icon,
                'poster': iconimage,
                'fanart': _fanart})
    if dmUser == "":
        playListInfos = "###MODE###=REMOVE###REFRESH###=TRUE###USER###={0}###THUMB###={1}###END###".format(name, iconimage)
        liz.addContextMenuItems([(translation(30029), 'RunPlugin(plugin://{0}/?mode=favourites&url={1})'.format(addonID, urllib_parse.quote_plus(playListInfos)),)])
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok


def get_key(heading):
    keyboard = xbmc.Keyboard('', heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()


def search(url):
    search_string = get_key(translation(30002))
    if search_string and len(search_string) > 2:
        url2 = url.replace("&search=", "&search={0}".format(urllib_parse.quote_plus(search_string)))
        addtoHistory({'name': search_string, 'url': urllib_parse.quote_plus(url2), 'mode': 'listVideos'})
        u = "{0}?url={1}&mode=listVideos".format(sys.argv[0], urllib_parse.quote_plus(url2))
        xbmc.executebuiltin("Container.Update({0})".format(u))


def searchLive():
    keyboard = xbmc.Keyboard('', '{0} {1}'.format(translation(30002), translation(30003)))
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        searchl_string = urllib_parse.quote_plus(keyboard.getText())
        listLive("{0}/videos?fields=id,thumbnail_large_url,title,views_last_hour&live_onair=1&search={1}&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, searchl_string, itemsPerPage, familyFilter, language))


def searchUser():
    keyboard = xbmc.Keyboard('', translation(30002) + ' ' + translation(30007))
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText():
        searchl_string = urllib_parse.quote_plus(keyboard.getText())
        listUsers("{0}/users?fields=username,avatar_large_url,videos_total,views_total&search={1}&limit={2}&family_filter={3}&localization={4}&page=1".format(urlMain, searchl_string, itemsPerPage, familyFilter, language))


def addtoHistory(item):
    if xbmcvfs.exists(HistoryFile):
        with open(HistoryFile, 'r') as fh:
            content = fh.read()
        if content.find(item["url"]) == -1:  # use url to verify
            with open(HistoryFile, 'a') as fh:
                fh.write(json.dumps(item) + "\n")
    else:
        with open(HistoryFile, 'a') as fh:
            fh.write(json.dumps(item) + "\n")


def History():
    if xbmcvfs.exists(HistoryFile):
        with open(HistoryFile, 'r') as fh:
            content = fh.readlines()
            if len(content) > 0:
                content = [json.loads(x) for x in content]
                reversed_content = content[::-1]  # reverse order
                addHistoryDir(reversed_content)
                addDir("[COLOR red]{0}[/COLOR]".format(translation(30116)), "", "delHistory", "{0}search.png".format(_ipath))
                xbmcplugin.endOfDirectory(pluginhandle, cacheToDisc=False)
                xbmcplugin.setContent(pluginhandle, "addons")
                if force_mode:
                    xbmc.executebuiltin('Container.SetViewMode({0})'.format(menu_mode))


def delHistory():
    if xbmcgui.Dialog().yesno("Dailymotion", translation(30121)):
        with open(HistoryFile, 'w') as fh:
            fh.write("")


def addHistoryDir(listofdicts):
    listoflists = []

    for item in listofdicts:
        liz = make_listitem(name=item["name"], labels={"genre": "History"})
        liz.setArt({"thumb": "{0}search.png".format(_ipath),
                    "icon": "{0}search.png".format(_ipath)})
        url = "{0}?url={1}&mode={2}".format(sys.argv[0], item["url"], item["mode"])
        listoflists.append((url, liz, True))

    ok = xbmcplugin.addDirectoryItems(pluginhandle, listoflists, len(listoflists))
    return ok


params = parameters_string_to_dict(sys.argv[2])
mode = urllib_parse.unquote_plus(params.get('mode', ''))
url = urllib_parse.unquote_plus(params.get('url', ''))
name = urllib_parse.unquote_plus(params.get('name', ''))

if mode == 'listVideos':
    listVideos(url)
elif mode == 'listLive':
    listLive(url)
elif mode == 'listUsers':
    listUsers(url)
elif mode == 'listChannels':
    listChannels()
elif mode == 'favourites':
    favourites(url)
elif mode == 'addFav':
    addFav()
elif mode == 'personalMain':
    personalMain()
elif mode == 'favouriteUsers':
    favouriteUsers()
elif mode == 'listUserPlaylists':
    listUserPlaylists(url)
elif mode == 'showPlaylist':
    showPlaylist(url)
elif mode == 'sortVideos1':
    sortVideos1(url)
elif mode == 'sortVideos2':
    sortVideos2(url)
elif mode == 'sortUsers1':
    sortUsers1()
elif mode == 'sortUsers2':
    sortUsers2(url)
elif mode == 'playVideo':
    playVideo(url)
elif mode == 'playLiveVideo':
    playVideo(url, live=True)
elif mode == 'playArte':
    playArte(url)
elif mode == "queueVideo":
    queueVideo(url, name)
elif mode == 'search':
    search(url)
elif mode == 'livesearch':
    searchLive()
elif mode == 'usersearch':
    searchUser()
elif mode == 'History':
    History()
elif mode == 'delHistory':
    delHistory()
else:
    index()
